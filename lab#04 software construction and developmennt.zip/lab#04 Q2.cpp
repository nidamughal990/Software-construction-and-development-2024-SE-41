#include <iostream>
#include <string>
using namespace std;
// Superclass
class Animal
{
protected:
    int animalID;
    string name;
    string species;
    int age;
    double weight;
    string healthStatus;
public:
    void getDetails()
    {
        cout << "Enter Animal ID: ";
        cin >> animalID;
        cout << "Enter Name: ";
        cin >> name;
        cout << "Enter Species: ";
        cin >> species;
        cout << "Enter Age: ";
        cin >> age;
        cout << "Enter Weight: ";
        cin >> weight;
        cout << "Enter Health Status: ";
        cin >> healthStatus;
    }

    void eat()
    {
        cout << name << " is eating." << endl;
    }

    void sleep()
    {
        cout << name << " is sleeping." << endl;
    }

    virtual void makeSound()
    {
        cout << name << " makes a sound." << endl;
    }

    virtual void displayInfo()
    {
        cout << "\nAnimal Information" << endl;
        cout << "Animal ID: " << animalID << endl;
        cout << "Name: " << name << endl;
        cout << "Species: " << species << endl;
        cout << "Age: " << age << endl;
        cout << "Weight: " << weight << endl;
        cout << "Health Status: " << healthStatus << endl;
    }

    virtual ~Animal() = default;
};

// Subclass Cat
class Cat : public Animal
{
private:
    int catID;
    string breed;
    string color;
    string gender;
    string ownerName;

public:
    void getCatDetails()
    {
        cout << "\nEnter Cat Details" << endl;

        getDetails();

        cout << "Enter Cat ID: ";
        cin >> catID;

        cout << "Enter Breed: ";
        cin >> breed;

        cout << "Enter Color: ";
        cin >> color;

        cout << "Enter Gender: ";
        cin >> gender;

        cout << "Enter Owner Name: ";
        cin >> ownerName;
    }

    void meow()
    {
        cout << name << " says Meow!" << endl;
    }

    void scratch()
    {
        cout << name << " is scratching." << endl;
    }

    void displayInfo() override
    {
        cout << "\nCat Information" << endl;
        Animal::displayInfo();
        cout << "Cat ID: " << catID << endl;
        cout << "Breed: " << breed << endl;
        cout << "Color: " << color << endl;
        cout << "Gender: " << gender << endl;
        cout << "Owner Name: " << ownerName << endl;
    }
};
// Subclass Dog
class Dog : public Animal
{
private:
    int dogID;
    string breed;
    string color;
    string gender;
    string ownerName;
    string vaccinationStatus;

public:
    void getDogDetails()
    {
        cout << "\nEnter Dog Details" << endl;
        getDetails();
        cout << "Enter Dog ID: ";
        cin >> dogID;
        cout << "Enter Breed: ";
        cin >> breed;
        cout << "Enter Color: ";
        cin >> color;
        cout << "Enter Gender: ";
        cin >> gender;

        cout << "Enter Owner Name: ";
        cin >> ownerName;
        cout << "Enter Vaccination Status: ";
        cin >> vaccinationStatus;
    }
    void bark()
    {
        cout << name << " says Woof!" << endl;
    }
    void wagTail()
    {
        cout << name << " is wagging its tail." << endl;
    }
    void displayInfo() override
    {
        cout << "\nDog Information" << endl;

        Animal::displayInfo();
        cout << "Dog ID: " << dogID << endl;
        cout << "Breed: " << breed << endl;
        cout << "Color: " << color << endl;
        cout << "Gender: " << gender << endl;
        cout << "Owner Name: " << ownerName << endl;
        cout << "Vaccination Status: "
             << vaccinationStatus << endl;
    }
};

int main()
{
    // Create Cat object
    Cat c;
    c.getCatDetails();
    c.displayInfo();
    cout << "\nCat Behaviors" << endl;
    c.eat();
    c.sleep();
    c.meow();
    c.scratch();
    cout << "\n------------------------" << endl;
    // Create Dog object
    Dog d;

    d.getDogDetails();
    d.displayInfo();

    cout << "\nDog Behaviors" << endl;
    d.eat();
    d.sleep();
    d.bark();
    d.wagTail();

    return 0;
}