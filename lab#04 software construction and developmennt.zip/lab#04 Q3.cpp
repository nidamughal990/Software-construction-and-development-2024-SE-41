#include <iostream>
#include <string>
using namespace std;
// Superclass
class Shape
{
protected:
    int shapeID;
    string shapeType;
public:
    // Pure virtual function
    virtual double area() = 0;
    // Display common shape information
    void getShapeInfo()
    {
        cout << "Shape ID: " << shapeID << endl;
        cout << "Shape Type: " << shapeType << endl;
    }
    // Set shape type
    void setShapeType(string type)
    {
        shapeType = type;
    }
    virtual ~Shape() = default;
};
// Subclass Triangle
class Triangle : public Shape
{
private:
    double base;
    double height;
    string color;
    int triangleID;
public:
    // Take triangle data from the user
    void getData()
    {
        cout << "\nEnter Triangle ID: ";
        cin >> triangleID;
        cout << "Enter Base: ";
        cin >> base;
        cout << "Enter Height: ";
        cin >> height;
        cout << "Enter Color: ";
        cin >> color;
        shapeID = triangleID;
        setShapeType("Triangle");
    }
    // Calculate triangle area
    double area() override
    {
        return 0.5 * base * height;
    }
    // Display triangle details
    void getDetails()
    {
        cout << "\n--- Triangle Details ---" << endl;
        getShapeInfo();

        cout << "Triangle ID: " << triangleID << endl;
        cout << "Base: " << base << endl;
        cout << "Height: " << height << endl;
        cout << "Color: " << color << endl;
        cout << "Area: " << area() << endl;
    }
    // Set triangle color
    void setColor(string newColor)
    {
        color = newColor;
    }
};
// Subclass Rectangle
class Rectangle : public Shape
{
private:
    double length;
    double width;
    string color;
    int rectangleID;

public:
    // Take rectangle data from the user
    void getData()
    {
        cout << "\nEnter Rectangle ID: ";
        cin >> rectangleID;
        cout << "Enter Length: ";
        cin >> length;
        cout << "Enter Width: ";
        cin >> width;
        cout << "Enter Color: ";
        cin >> color;
        shapeID = rectangleID;
        setShapeType("Rectangle");
    }
    // Calculate rectangle area
    double area() override
    {
        return length * width;
    }
    // Display rectangle details
    void getDetails()
    {
        cout << "\n--- Rectangle Details ---" << endl;
        getShapeInfo();
        cout << "Rectangle ID: " << rectangleID << endl;
        cout << "Length: " << length << endl;
        cout << "Width: " << width << endl;
        cout << "Color: " << color << endl;
        cout << "Area: " << area() << endl;
    }
    // Set rectangle color
    void setColor(string newColor)
    {
        color = newColor;
    }
};
// Main function
int main()
{
    // Create Triangle object
    Triangle t;
    cout << "TRIANGLE AREA CALCULATION" << endl;
    t.getData();
    t.getDetails();
    cout << "\n--------------------------\n" << endl;
    // Create Rectangle object
    Rectangle r;
    cout << "RECTANGLE AREA CALCULATION" << endl;
    r.getData();
    r.getDetails();
    return 0;
}